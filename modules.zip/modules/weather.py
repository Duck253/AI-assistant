import requests

def get_weather(city):
    API_KEY = "ac98607ec1d89b0dc9e06b1eff62d3e9"  # Replace with your real API key if needed
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        if "main" in data:
            temp = data["main"]["temp"]
            weather = data["weather"][0]["description"]
            return f"The weather in {city} is {weather} with a temperature of {temp}°C."
        else:
            return f"❌ Couldn't get weather info for '{city}'."

    except requests.exceptions.RequestException as e:
        return f"⚠️ Network error while fetching weather: {e}"
    except Exception as e:
        return f"⚠️ Unexpected error: {e}"


# Example usage
if __name__ == "__main__":
    city = input("Enter city: ")
    print(get_weather(city))
