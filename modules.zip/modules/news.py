import requests

class News:
    API_KEY = "3382b5d6c4684f06b24f7c50d8965f1b"  # Replace with your own API key
    BASE_URL = "https://newsapi.org/v2/top-headlines"

    @classmethod
    def get_top_headlines(cls, country="us", limit=5):
        url = f"{cls.BASE_URL}?country={country}&apiKey={cls.API_KEY}"
        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            if "articles" not in data or not data["articles"]:
                return "❌ No news found."

            headlines = [article["title"] for article in data["articles"][:limit]]
            return "🗞️ Top News Headlines:\n" + "\n".join(f"- {title}" for title in headlines)

        except requests.exceptions.RequestException as e:
            return f"⚠️ Network error: {e}"
        except Exception as e:
            return f"⚠️ Unexpected error: {e}"
