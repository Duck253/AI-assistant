import urllib.parse
import webbrowser
import pandas as pd
import random

# Load the Spotify dataset
df_spotify = pd.read_csv("data/Spotify-2000.csv")

# Define mood filters
MOOD_FILTERS = {
    "happy": lambda df: df[(df["Valence"] > 70) & (df["Energy"] > 60)],
    "sad": lambda df: df[(df["Valence"] < 30) & (df["Acousticness"] > 50)],
    "energetic": lambda df: df[(df["Energy"] > 80) & (df["Danceability"] > 70)],
    "chill": lambda df: df[(df["Energy"] < 40) & (df["Acousticness"] > 60)]
}

def recommend_song(mood, df=df_spotify):
    mood = mood.lower()
    if mood not in MOOD_FILTERS:
        return None, None

    candidates = MOOD_FILTERS[mood](df)
    if candidates.empty:
        return None, None

    choice = candidates.sample(1).iloc[0]
    return choice["Title"], choice["Artist"]

def play_song(query):
    search_query = urllib.parse.quote(query)
    url = f"https://www.youtube.com/results?search_query={search_query}"
    print(f"🎗️ Opening YouTube for: {query}")
    webbrowser.open(url)
    return f"🎶 Playing: {query} on YouTube"