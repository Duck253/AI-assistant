import os
import platform
import subprocess


def stream_radio_vlc(url):
    """
    Stream a radio URL using VLC media player based on the OS.

    Parameters:
    - url (str): The streaming URL to be opened in VLC
    """
    if platform.system() == "Windows":
        vlc_path = r"C:\\Program Files\\VideoLAN\\VLC\\vlc.exe"
        if not os.path.exists(vlc_path):
            print("❌ VLC not found. Make sure it's installed in the default location.")
            return
        subprocess.Popen([vlc_path, url])

    elif platform.system() == "Darwin":  # macOS
        subprocess.call(["/Applications/VLC.app/Contents/MacOS/VLC", url])

    elif platform.system() == "Linux":
        subprocess.Popen(["vlc", url])

    else:
        print("❌ Unsupported OS")
