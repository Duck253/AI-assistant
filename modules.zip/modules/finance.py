import requests


def get_stock_price(symbol):
    API_KEY = "WPVdAjX5dAWMs75kXwcsGjKDIbCuNrkn"  # Replace with your actual API key
    url = f"https://financialmodelingprep.com/api/v3/quote/{symbol.upper()}?apikey={API_KEY}"

    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        if not data:
            return f"❌ No stock data found for '{symbol.upper()}'."

        name = data[0].get("name", symbol.upper())
        price = data[0].get("price")

        if price is None:
            return f"⚠️ Price not available for '{symbol.upper()}'."

        return f"💹 {name} ({symbol.upper()}) stock price: ${price:.2f}"

    except requests.exceptions.RequestException as e:
        return f"⚠️ Network error: {e}"
    except Exception as e:
        return f"⚠️ Unexpected error: {e}"