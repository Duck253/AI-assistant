import wikipedia

def answer_general_question(query):
    try:
        wikipedia.set_lang("en")

        # Try to directly fetch a page for the exact query
        try:
            summary = wikipedia.summary(query, sentences=2)
            return f"📘 {query.title()}:\n{summary}"
        except wikipedia.exceptions.PageError:
            # Fallback to search
            search_results = wikipedia.search(query)
            if not search_results:
                return "❌ I couldn't find anything related to your question."

            # Try best matching title
            for title in search_results:
                if query.lower() in title.lower():
                    summary = wikipedia.summary(title, sentences=2)
                    return f"📘 {title}:\n{summary}"

            # As last resort, try first result
            summary = wikipedia.summary(search_results[0], sentences=2)
            return f"📘 {search_results[0]}:\n{summary}"

    except wikipedia.exceptions.DisambiguationError as e:
        return f"🤔 That question is too broad. Try being more specific, e.g.:\n- {e.options[0:3]}"
    except Exception as e:
        return f"⚠️ Error: {e}"
