import pandas as pd
import re

DF_FOOD = pd.read_csv("data/Food and Calories - Sheet1.csv")
DF_FOOD.columns = DF_FOOD.columns.str.strip().str.lower()

if "calories_num" not in DF_FOOD.columns:
    DF_FOOD["calories_num"] = DF_FOOD["calories"].astype(str).str.extract(r"(\d+\.?\d*)")[0].astype(float)
    DF_FOOD["food"] = DF_FOOD["food"].str.strip().str.lower()

def analyze_food_intake(user_input, df=DF_FOOD):
    df.columns = [c.strip().lower() for c in df.columns]

    items = [item.strip().lower() for item in user_input.split(",")]
    total_calories = 0.0
    summary_lines = []

    for item in items:
        m = re.match(r"^(\d+)\s+(.*)$", item)
        if m:
            qty = int(m.group(1))
            name = m.group(2).strip()
        else:
            qty = 1
            name = item

        singular = name[:-1] if name.endswith("s") else name

        match = df[df["food"] == name]
        if match.empty:
            match = df[df["food"].str.contains(rf"\b{re.escape(singular)}\b")]

        if not match.empty:
            cal = float(match.iloc[0]["calories_num"])
            total = qty * cal
            total_calories += total
            summary_lines.append(f"- {qty} {name.title()}: {total:.2f} kcal")
        else:
            summary_lines.append(f"- {qty} {name.title()}: Not found kcal")

    summary = "\U0001F9FE Food Intake Summary:\n" + "\n".join(summary_lines)
    summary += f"\n\n\U0001F525 Total Calories: {total_calories:.2f} kcal"

    if total_calories < 800:
        summary += "\n\U0001F957 You might need to eat more to meet your daily energy needs!"
    elif total_calories > 2500:
        summary += "\n\u26A0\ufe0f That’s quite a bit! Consider balancing your intake."

    return summary
