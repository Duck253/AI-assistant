import requests

def search_medical_condition(term, max_results=5):
    url = "https://clinicaltables.nlm.nih.gov/api/conditions/v3/search"
    params = {
        "terms": term,
        "maxList": max_results,
        "sf": "consumer_name",     # search field
        "df": "consumer_name"      # display field
    }

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()

        # Use data[1] if it contains names, else fallback to data[3]
        condition_names = data[1]
        if not condition_names or not condition_names[0].isalpha():
            condition_names = [row[0] for row in data[3]]

        if condition_names:
            return f"🦥 Conditions related to '{term}':\n" + "\n".join(f"- {name}" for name in condition_names)
        else:
            return f"❌ No conditions found for '{term}'."

    except Exception as e:
        return f"⚠️ Error fetching medical data: {e}"