import json
import os
import re
import dateparser
from datetime import datetime

SCHEDULE_FILE = "schedule.json"

class Scheduler:
    def __init__(self, filepath=SCHEDULE_FILE):
        self.filepath = filepath
        self.schedule = self.load()

    def load(self):
        if not os.path.exists(self.filepath):
            return []
        with open(self.filepath, 'r') as f:
            return json.load(f)

    def save(self):
        with open(self.filepath, 'w') as f:
            json.dump(self.schedule, f, indent=2)

    def parse_schedule_intent(self, text):
        text = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2})', r'\1 \2', text)
        dt = dateparser.parse(text)
        if not dt:
            return None, None

        task = re.sub(r'\bat\b.*$', '', text, flags=re.IGNORECASE)
        task = re.sub(r'\b(remind me to|remind me|schedule|add|create|note|set a reminder to)\b', '', task, flags=re.IGNORECASE).strip()
        return task.capitalize() if task else "Untitled Task", dt

    def add_schedule(self, raw_input=None):
        if raw_input:
            task, dt = self.parse_schedule_intent(raw_input)
            if task and dt:
                return self._add_task(task, dt)
            else:
                print("❌ I couldn't understand. Let's do it manually.")

        task = input("📝 Enter task: ")
        time_str = input("⏰ Enter date & time (e.g., 2025-08-05 17:10): ").strip()
        time_str = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2})', r'\1 \2', time_str)
        dt = dateparser.parse(time_str)
        if task and dt:
            return self._add_task(task, dt)
        return "❌ Still couldn't parse it. Try again."

    def _add_task(self, task, dt):
        new_event = {
            "title": task,
            "date": dt.strftime("%Y-%m-%d"),
            "time": dt.strftime("%H:%M")
        }
        if new_event not in self.schedule:
            self.schedule.append(new_event)
            self.save()
            return f"✅ Task scheduled: '{task}' at {dt.strftime('%Y-%m-%d %H:%M')}"
        else:
            return "⚠️ This task already exists."

    def view_schedule(self):
        if not self.schedule:
            return "📭 No scheduled tasks."
        result = "📋 Upcoming Tasks:\n"
        for item in self.schedule:
            result += f"- {item['title']} at {item['date']} {item['time']}\n"
        return result.strip()

    def delete_schedule(self):
        if not self.schedule:
            return "📭 No tasks to delete."
        print("🗑️ Current Schedule:")
        for i, item in enumerate(self.schedule):
            print(f"{i + 1}. {item['title']} at {item['date']} {item['time']}")
        try:
            choice = int(input("Enter the number of the task to delete: "))
            if 1 <= choice <= len(self.schedule):
                removed = self.schedule.pop(choice - 1)
                self.save()
                return f"✅ Deleted: '{removed['title']}'"
            else:
                return "❌ Invalid choice."
        except ValueError:
            return "❌ Please enter a valid number."

    def daily_summary(self):
        today = datetime.now().strftime("%Y-%m-%d")
        today_events = [e for e in self.schedule if e["date"] == today]
        if not today_events:
            return "📭 No scheduled events for today."
        summary = "📅 Today's Events:\n"
        for event in today_events:
            summary += f"- {event['title']} at {event['time']}\n"
        return summary.strip()
