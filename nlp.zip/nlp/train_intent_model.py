from datasets import load_dataset, Dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
import pandas as pd
import torch
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split


# Load and encode dataset
df = pd.read_csv("C:/Users/ADMIN/PycharmProjects/MyProject1/.venv/data/intent_dataset.csv")  # Adjust path if needed
label_encoder = LabelEncoder()
df["label"] = label_encoder.fit_transform(df["intent"])

# Convert to HuggingFace Dataset
dataset = Dataset.from_pandas(df[["text", "label"]])

# Tokenizer and model
model_name = "distilbert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)

def tokenize(batch):
    return tokenizer(batch["text"], padding="max_length", truncation=True, max_length=32)

dataset = dataset.map(tokenize, remove_columns=["text"])


# Split dataset
dataset = dataset.train_test_split(test_size=0.2)
train_dataset = dataset["train"]
test_dataset = dataset["test"]

# Load model
model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=len(label_encoder.classes_))

# Training arguments
training_args = TrainingArguments(
    output_dir="./intent_model",
    per_device_train_batch_size=8,
    num_train_epochs=5,
    logging_dir="./logs"
)

# Compute metrics
def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=1)
    return {"accuracy": accuracy_score(labels, preds)}

# Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
    compute_metrics=compute_metrics,
)

# Train the model
trainer.train()

# Save model and label encoder
model.save_pretrained("intent_model")
tokenizer.save_pretrained("intent_model")
import joblib
joblib.dump(label_encoder, "intent_model/label_encoder.pkl")
